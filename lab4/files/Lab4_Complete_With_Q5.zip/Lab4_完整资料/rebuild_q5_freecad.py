"""FreeCAD 1.0: a genuine editable, fully constrained Q5 teaching model.
All dimensions are chosen approximations, not source measurements.
Run with a Python interpreter that can import FreeCAD, Part and Sketcher.
"""
import sys,json
from pathlib import Path
sys.path.extend(['/usr/lib/freecad/lib','/usr/share/freecad/Mod'])
import FreeCAD as A,Part,Sketcher
out=Path(__file__).resolve().parent; (out/'models').mkdir(exist_ok=True)
doc=A.newDocument('Q5_Teaching_Model');body=doc.addObject('PartDesign::Body','Body')
body.addProperty('App::PropertyString','Source','Teaching');body.Source='lab03_hw.pdf, page 5, Question 4; used by Lab 4 Q5'
body.addProperty('App::PropertyString','DimensionStatus','Teaching');body.DimensionStatus='ALL sizes are chosen educational approximations; no sizes given in source.'
body.addProperty('App::PropertyString','AllowedFeatures','Teaching');body.AllowedFeatures='Two Pads (Boss-Extrude) and three Pockets (Cut-Extrude). No mirror, fillet or pattern.'
body.addProperty('App::PropertyString','Axes','Teaching');body.Axes='X length, Y height, Z depth. Front symmetry plane Z=0. Viewer coordinates map to (X,Z,-Y).'
sketches=[]
def poly(name,pts,placement):
 sk=body.newObject('Sketcher::SketchObject',name);sk.Placement=placement
 n=len(pts)
 for i in range(n):
  a,b=pts[i],pts[(i+1)%n];sk.addGeometry(Part.LineSegment(A.Vector(*a,0),A.Vector(*b,0)),False)
 for i in range(n):sk.addConstraint(Sketcher.Constraint('Coincident',i,2,(i+1)%n,1))
 for i,(x,y) in enumerate(pts):
  sk.addConstraint(Sketcher.Constraint('DistanceX',i,1,x) if abs(x)>1e-9 else Sketcher.Constraint('PointOnObject',i,1,-2))
  sk.addConstraint(Sketcher.Constraint('DistanceY',i,1,y) if abs(y)>1e-9 else Sketcher.Constraint('PointOnObject',i,1,-1))
 doc.recompute();sketches.append(sk);return sk

def bore(name,z):
 sk=body.newObject('Sketcher::SketchObject',name);sk.Placement=A.Placement(A.Vector(0,0,z),A.Rotation())
 sk.addGeometry(Part.Circle(A.Vector(40,20,0),A.Vector(0,0,1),10),False)
 sk.addConstraint(Sketcher.Constraint('DistanceX',0,3,40.0));sk.addConstraint(Sketcher.Constraint('DistanceY',0,3,20.0));sk.addConstraint(Sketcher.Constraint('Diameter',0,20.0));doc.recompute();sketches.append(sk);return sk

sk=poly('Sketch_Body',[(0,20),(12,0),(60,0),(60,40),(12,40)],A.Placement())
p1=body.newObject('PartDesign::Pad','Boss_Body');p1.Profile=sk;p1.Length=48;p1.Midplane=True;doc.recompute()
sk=poly('Sketch_Rise',[(0,20),(8,47),(8,20)],A.Placement())
p2=body.newObject('PartDesign::Pad','Boss_Rise');p2.Profile=sk;p2.Length=20;p2.Midplane=True;doc.recompute()
sk=poly('Sketch_Opening',[(8,-18),(56,-18),(56,18),(8,18)],A.Placement(A.Vector(0,0,0),A.Rotation(A.Vector(1,0,0),90)))
p3=body.newObject('PartDesign::Pocket','Cut_Opening');p3.Profile=sk;p3.Type=1;doc.recompute()
sk=bore('Sketch_FrontBore',24)
p4=body.newObject('PartDesign::Pocket','Cut_FrontBlind');p4.Profile=sk;p4.Length=4;doc.recompute()
sk=bore('Sketch_RearBore',-24)
p5=body.newObject('PartDesign::Pocket','Cut_RearBlind');p5.Profile=sk;p5.Length=4;p5.Reversed=True;doc.recompute()
for sk in sketches:
 assert sk.FullyConstrained,(sk.Name,sk.FullyConstrained)
for p in [p1,p2,p3,p4,p5]:
 print(p.Name,p.Shape.Volume,len(p.Shape.Solids),p.State)
 assert p.Shape.isValid() and len(p.Shape.Solids)==1
assert abs(p5.Shape.Volume-34100.059210461484)<1e-5,p5.Shape.Volume
body.Tip=p5
for obj in [*sketches,p1,p2,p3,p4]:
 if obj.ViewObject:obj.ViewObject.Visibility=False
if p5.ViewObject:p5.ViewObject.Visibility=True
# Descriptive labels without changing the native parametric feature types.
p1.Label='01 Boss-Extrude | Mid Plane 48';p2.Label='02 Boss-Extrude | Mid Plane 20'
p3.Label='03 Cut-Extrude | Through All';p4.Label='04 Cut-Extrude | Blind 4';p5.Label='05 Cut-Extrude | Blind 4'
doc.recompute();doc.saveAs(str(out/'models'/'Q5_Editable_FreeCAD.FCStd'))
record={'version':A.Version()[:3],'sketches':[{ 'name':sk.Name,'fully_constrained':sk.FullyConstrained,'constraints':sk.ConstraintCount} for sk in sketches],'feature_types':[p.TypeId for p in [p1,p2,p3,p4,p5]],'final_volume_mm3':p5.Shape.Volume,'valid':p5.Shape.isValid(),'solids':len(p5.Shape.Solids)}
(out/'freecad_validation.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2));A.closeDocument(doc.Name)
