import cadquery as c, math,json,os
from pathlib import Path
out=Path(__file__).resolve().parent; (out/'models').mkdir(exist_ok=True); stages={}; results={}
def add(q,name,s): stages.setdefault(q,[]).append((name,s))
def box(x,y,z,dx,dy,dz):return c.Workplane('XY').box(dx,dy,dz,centered=(False,False,False)).translate((x,y,z))
s=box(0,0,0,60,28,30);add('Q1','底座 / Base · 60 × 28 × 30',s)
s=s.union(box(0,0,30,48,20,8));add('Q1','一级台阶 / Step 1 · 48 × 20 × 8',s)
s=s.union(box(0,0,38,32,20,12));add('Q1','二级台阶 / Step 2 · 32 × 20 × 12',s)
s=s.union(box(0,0,50,20,20,25));add('Q1','高台阶 / Tall step · 20 × 20 × 25',s)
s=s.cut(c.Workplane('XZ').center(44,16).circle(6).extrude(-28));add('Q1','Ø12 贯穿孔 / Through hole',s)
k=7/38;t=math.sqrt(1-k*k)
p=[(16*k,16*t),(38+9*k,9*t),(38+9*k,-9*t),(16*k,-16*t)]
s=c.Workplane('XY').polyline(p).close().extrude(6).union(c.Workplane('XY').circle(16).extrude(6)).union(c.Workplane('XY').center(38,0).circle(9).extrude(6));add('Q2','相切连接板 / Tangent link · 6',s)
s=s.union(c.Workplane('XY').workplane(offset=6).circle(16).extrude(8));add('Q2','大端凸台 / Large boss · total 14',s)
s=s.union(c.Workplane('XY').center(38,0).circle(9).extrude(-24));add('Q2','下圆柱 / Lower boss · 24',s)
s=s.cut(c.Workplane('XY').circle(10).extrude(14)).cut(c.Workplane('XY').workplane(offset=-24).center(38,0).circle(3).extrude(30));add('Q2','Ø20、Ø6 贯穿 / Through holes',s)
s=c.Workplane('XY').center(17.5,0).rect(35,52).extrude(7)
es=[e for e in s.val().Edges() if e.geomType()=='LINE' and abs(e.Center().x)<1e-6 and abs(e.Length()-7)<1e-6]
s=s.newObject(es).fillet(10);add('Q3','底板与前角 / Base · 52 × 35 × 7, R10',s)
s=s.union(c.Workplane('XY').workplane(offset=7).center(22,0).rect(26,34).extrude(25));add('Q3','立台 / Wall · 26 × 34 × 25',s)
es=[e for e in s.val().Edges() if e.geomType()=='LINE' and abs(e.Center().z-7)<1e-6 and abs(abs(e.Center().y)-17)<1e-6 and e.Length()>20]
s=s.newObject(es).fillet(5);add('Q3','底部圆角 / Root fillets · R5',s)
s=s.cut(c.Workplane('XY').center(25.5,0).rect(19,20).extrude(40));add('Q3','后侧开口 / Rear opening · 19 × 20, Through All',s)
lug=c.Workplane('YZ').moveTo(-7.5,7).lineTo(7.5,7).lineTo(7.5,15).threePointArc((0,22.5),(-7.5,15)).close().extrude(5)
s=s.union(lug);add('Q3','前耳板 / Front lug · R7.5, thickness 5',s)
s=s.cut(c.Workplane('YZ').center(0,15).circle(3).extrude(40));add('Q3','Ø6 全贯穿 / Through All',s)
# Q4 native inches, export/model coordinates mm
u=25.4;left=-.15;neck=left+math.sqrt(.16-.04);d=neck+3.25+math.sqrt(.16-.04)
a=c.Workplane('XY').center(left,0).circle(.4).extrude(.3).intersect(box(-.4,-2,0,6,4,1))
s=a.union(c.Workplane('XY').center(d,0).circle(.4).extrude(.3)).union(c.Workplane('XY').center((neck+d)/2,0).rect(d-neck,.4).extrude(.3)).translate((0,0,-.15));add('Q4','轮廓中面拉伸 / Mid Plane · 0.3 in',s)
s=s.cut(c.Workplane('XY').workplane(offset=-.15).polyline([(-1,-.25),(-.15,-.25),(0,0),(-.15,.25),(-1,.25)]).close().extrude(.3));add('Q4','开口端切除 / Open jaw · 0.5 in',s)
p=[(d+.5/math.sqrt(3)*math.cos(i*math.pi/3),.5/math.sqrt(3)*math.sin(i*math.pi/3)) for i in range(6)]
s=s.cut(c.Workplane('XY').workplane(offset=-.15).polyline(p).close().extrude(.3));add('Q4','正六边形贯穿 / Hexagon · AF 0.5 in',s)
def build_q5():
    stages=[]
    # Tutorial axes: X length, Y depth, Z height. Front Plane is Y=0.
    s=c.Workplane('XZ').polyline([(0,20),(12,0),(60,0),(60,40),(12,40)]).close().extrude(24,both=True)
    stages.append(('五边形主体 / Boss-Extrude · Mid Plane 48',s,'Boss-Extrude'))
    rib=c.Workplane('XZ').polyline([(0,20),(8,47),(8,20)]).close().extrude(10,both=True)
    s=s.union(rib)
    stages.append(('中央三角凸起 / Boss-Extrude · Mid Plane 20',s,'Boss-Extrude'))
    opening=c.Workplane('XY').center(32,0).rect(48,36).extrude(60,both=True)
    s=s.cut(opening)
    stages.append(('矩形贯穿开口 / Cut-Extrude · 48 × 36',s,'Cut-Extrude'))
    front_hole=c.Workplane('XZ').center(40,20).circle(10).extrude(-4).translate((0,-24,0))
    s=s.cut(front_hole)
    stages.append(('前侧盲孔 / Cut-Extrude · Ø20 depth 4',s,'Cut-Extrude'))
    rear_hole=c.Workplane('XZ').center(40,20).circle(10).extrude(4).translate((0,24,0))
    s=s.cut(rear_hole)
    stages.append(('后侧盲孔 / Cut-Extrude · Ø20 depth 4',s,'Cut-Extrude'))
    return stages

for name,part,kind in build_q5():add('Q5',name,part)

refs={'Q1':72593,'Q2':16268,'Q3':23361,'Q4':.5492,'Q5':None};data={}
for q,ss in stages.items():
 data[q]=[]
 for si,(name,s) in enumerate(ss):
  shape=s.val();shape=shape.scale(25.4) if q=='Q4' else shape
  assert shape.isValid() and len(shape.Solids())==1,(q,si)
  verts,faces=shape.tessellate(.12,.15)
  vs=[list(v.toTuple()) for v in verts];fs=[list(f) for f in faces]
  edges=[]
  for e in shape.Edges():
   typ=e.geomType();pts=[list(v.toTuple()) for v in e.sample(48 if typ!='LINE' else 2)[0]]
   if e.IsClosed():pts.append(pts[0])
   record={'type':typ,'length':e.Length(),'points':pts,'start':list(e.startPoint().toTuple()),'end':list(e.endPoint().toTuple())}
   if typ=='CIRCLE':record.update(radius=e.radius(),center=list(e.arcCenter().toTuple()))
   edges.append(record)
  data[q].append({'title':name,'vertices':vs,'faces':fs,'edges':edges,'volume':shape.Volume()})
 final=ss[-1][1].val();nativev=final.Volume();shape=final.scale(25.4) if q=='Q4' else final
 c.exporters.export(shape.rotate((0,0,0),(1,0,0),-90),str(out/'models'/f'{q}.step'))
 results[q]={'volume':nativev,'reference':refs[q],'error_pct':(nativev/refs[q]-1)*100 if refs[q] is not None else None,'valid':shape.isValid(),'solids':len(shape.Solids()),'stages':len(ss)}
json.dump(data,open(out/'model_data.json','w'),ensure_ascii=False,separators=(',',':'))
json.dump(results,open(out/'validation.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(results,indent=2))
