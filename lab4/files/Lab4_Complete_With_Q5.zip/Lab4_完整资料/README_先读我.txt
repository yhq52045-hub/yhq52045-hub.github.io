Lab 4 - Part Modelling I / 零件建模I
完整版：Q5已根据新增Lab 3第4题补齐。

一、先打开什么
- Lab4_Bilingual_Guide.docx / .pdf：46页完整中英对照讲义。
  包含Lab 4全部5题、最终图、23个建模阶段、详细双语步骤。
  Q5另外包含其引用的Lab 3第4题三个小问及侧视半剖图。
- Lab4_Interactive.html：现代浏览器离线打开，默认Q5。
  模型、教学文字及原题配图均内嵌，不依赖网络或CDN。
- models/Q1.step—Q5.step：5个标准实体文件，可导入SolidWorks。
- models/Q5_Editable_FreeCAD.FCStd：真正可编辑的FreeCAD原生文件。
  五个草图全部完全约束；仅两个Pad（拉伸凸台）与三个Pocket（拉伸切除）。
- Q5_Isometric_On_Dot_Paper.pdf：在你上传的等轴测点阵纸上绘制的教学图。
- Q5_Half_Section.pdf：关联Lab 3第4题的侧视半剖示意。

二、交互操作
左键拖动旋转；滚轮缩放；右键或Shift拖动平移。
点击边线或完整边线表查询长度、端点；圆弧另有圆心、半径和直径。
上/下一步按钮或左侧特征阶段树可切换建模阶段。
“两点测距”模式选择两处几何端点；ESC清空选择。
标准视图按钮支持前视、俯视、右视与等轴测。
可切换mm/in，切换线框，也可保存当前视角为PNG。
闭合圆的起止点相同，查询圆心请看圆弧属性。
WebGL需启用；HTML用于教学查看，不含完整的草图编辑/参数求解功能。

三、尺寸和基准面
Q1—Q4按标注重建，体积均在题目参考值±1%内。
Q4的原文单位矛盾已说明，按英寸理解；所有STEP统一以毫米导出。
Q5题图无尺寸，Lab 4要求按外观估计而不要精确量取。
Q5全部数值为便于学习选定的近似值，不是原图精确尺寸，没有官方参考体积。
Q5采用两侧各深4的Ø20盲孔，侧壁厚6、孔底剩余2；不能替换成贯穿孔。
Q5矩形开口贯穿上下；中央三角凸起关于深度中面对称。

教程/查看器轴向：X为长，Y为深，Z为高。
STEP及FreeCAD轴向：(X,Y,Z)=(教学X,教学Z,-教学Y)。
因此导出文件中Front Plane为Z=0，Top Plane为Y=0，原点不变。
Q2、Q3、Q4与Q5的对称面均对应Front Plane。

SolidWorks：文件→打开→选择STEP，按需使用导入诊断。
STEP保留实体几何，不保留SolidWorks原生草图/特征树；照本教程重画可建立原生特征。
当前环境未运行SolidWorks，不提供或冒充.sldprt文件。
要编辑Q5，直接在FreeCAD打开.FCStd，展开Body编辑草图或Pad/Pocket参数。

四、其余资料
images/：每个阶段图、最终图、投影核对、半剖图、原题图和交互预览。
原文提取与翻译.md：可复制的全部Lab 4题干及中英对照步骤，另含Lab 3第4题。
最终模型边线尺寸_mm.csv：所有最终模型的边线几何属性，坐标采用教学轴向。
model_data.json：三维显示网格及CAD边线数据，单位mm。
validation.json：23个阶段与最终几何校验记录。
freecad_validation.json：FreeCAD约束、特征类型及体积核验记录。
viewer_test.json：实际浏览器操作与查询测试记录。
rebuild_models.py：需要Python+cadquery，可重建五个STEP模型及几何数据；不自动更新HTML内嵌数据。
rebuild_q5_freecad.py：需要能导入FreeCAD模块的Python，可重建原生Q5文件。

源文件：
原题.pdf 为Lab 4原文件；Lab3_原题.pdf 为本次补充的完整5页Lab 3。
isometric-dot-paper_原纸.pdf 为用户提供的空白点阵纸。
本次新增内容只针对Lab 4 Q5及其引用的Lab 3第4题，没有扩展Lab 3其余各题。

核验结果：
Q1 72593.274605 mm³，参考72593 ±1%
Q2 16267.915145 mm³，参考16268 ±1%
Q3 23361.034277 mm³，参考23361 ±1%
Q4 0.549621559 in³，参考0.5492 ±1%
Q5 34100.059210 mm³，为本教学近似模型的体积，无参考体积。
Q5原生FreeCAD与STEP/CAD内核独立重建的体积一致。
