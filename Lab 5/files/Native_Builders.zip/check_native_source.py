"""Static source checks only; not a VBA compiler or SOLIDWORKS runtime test."""
from pathlib import Path
import re, json, hashlib, zipfile

ROOT=Path(__file__).parent
EXPECTED={'FeatureExtrusion2':23,'FeatureCut3':26,'FullyDefineSketch':10}

def args_count(s):
    depth=0; quoted=False; count=1; i=0
    while i<len(s):
        c=s[i]
        if c=='"':
            if quoted and i+1<len(s) and s[i+1]=='"':i+=2;continue
            quoted=not quoted
        if not quoted:
            if c=='(':depth+=1
            elif c==')':depth-=1
            elif c==',' and depth==0:count+=1
        i+=1
    return count

results=[]
for q in range(1,5):
    path=ROOT/f'Lab5_Q{q}_Native.bas'; text=path.read_text(); checks={}
    checks['module_name']=f'Attribute VB_Name = "Lab5_Q{q}_Native"' in text
    checks['ascii_source']=text.isascii()
    checks['sub_blocks']=len(re.findall(r'^(?:Public |Private )?Sub\b',text,re.M))==len(re.findall(r'^End Sub\b',text,re.M))
    checks['function_blocks']=len(re.findall(r'^(?:Public |Private )?Function\b',text,re.M))==len(re.findall(r'^End Function\b',text,re.M))
    checks['long_lines']=max(map(len,text.splitlines()))<1023
    calls=[]
    for method,n in EXPECTED.items():
        for m in re.finditer(r'\.'+method+r'\((.*)\)',text):
            got=args_count(m.group(1));calls.append({'method':method,'arguments':got,'expected':n})
    checks['api_argument_counts']=all(c['arguments']==c['expected'] for c in calls)
    checks['no_imported_body_shortcut']=not re.search(r'\b(?:InsertImportedFeature|LoadFile4|ImportStepData)\b',text)
    # sgFIXED occurs only on standalone local reference datums.
    fixed=re.findall(r'^\s*(.*"sgFIXED".*)$',text,re.M)
    checks['fixed_reference_datums_only']=all('datum' in line.lower() for line in fixed)
    checks['main_does_not_save']='SaveAs' not in text.split('Public Sub main()')[1].split('Private Sub Initialise()')[0]
    checks['save_checks_absorbed_sketches']='GetFirstSubFeature' in text and 'CheckFeatureSketches child' in text
    checks['save_requires_volume_and_one_solid']='If Abs(vol - ' in text and 'If UBound(bodies) <> 0 Then Fail' in text
    checks['save_no_overwrite']='If fs.FileExists(path) Then Fail' in text
    if q==4:
        build=text.split('Private Sub BuildPart()')[1]
        checks['q4_no_auto_coordinate_dimensions']='FinishSketch True' not in build
        checks['q4_updated_end_points']='Array(77.0#, -16.0#, 0.0#)' in build and 'Array(77.0#, 20.0#, 0.0#)' in build
        checks['q4_derived_slot_12']='LengthDimension b, 12#' in build and '2 * (""EndHeight"" - ""BottomOffset"" - ""UpperWall"")' in build
        checks['q4_width_midplane']='Boss(48#, Array(0#, 0#, 1#), True' in build
        checks['q4_shoulder_depth_equations']=build.count('(""FullWidth"" - ""NeckWidth"") / 2')==2
    result={'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'checks':checks,'apiCalls':calls,'passed':all(checks.values())}
    results.append(result)
report={'validationLevel':'static source only; not compiled, executed or tested in SOLIDWORKS','nativeSldprtDelivered':False,'q4FullyDefined':False,'q4RequiresManualConstraintCompletion':True,'results':results,'allStaticChecksPass':all(x['passed'] for x in results)}
(ROOT/'native_static_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
assert report['allStaticChecksPass'],json.dumps(report,indent=2)
with zipfile.ZipFile(ROOT/'Lab5_Native_Builders_Source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.glob('*.bas')):z.write(p,p.name)
    for name in ['README_NATIVE_ZH_EN.md','native_static_validation.json']:z.write(ROOT/name,name)
print(json.dumps({'allStaticChecksPass':True,'files':[r['file'] for r in results],'nativeSldprtDelivered':False,'q4FullyDefined':False},indent=2))
