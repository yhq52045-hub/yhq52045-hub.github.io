"""Create local SOLIDWORKS VBA source; this does NOT execute SOLIDWORKS."""
from pathlib import Path
import json, math

ROOT = Path('/workspace/work')
OUT = ROOT/'native'
LIB = (OUT/'native_common.txt').read_text()

def vb(n):
    if isinstance(n,(list,tuple)):
        return 'Array('+', '.join(vb(x) for x in n)+')'
    v=f'{float(n):.13f}'.rstrip('0').rstrip('.')
    return (v if '.' in v else v+'.0')+'#'

def pts2(points,z=0):return [[*p,z] for p in points]
def write(q,ref,body):
    text=f'Attribute VB_Name = "Lab5_Q{q}_Native"\n'+LIB.replace('QUESTION_NUMBER',str(q)).replace('REFERENCE_VOLUME',str(ref)+'#')+'\n'+body
    (OUT/f'Lab5_Q{q}_Native.bas').write_text(text,encoding='utf-8')

q1=json.loads((ROOT/'q1/native_spec.json').read_text())
body=['Private Sub BuildPart()','    Dim segments, f As Object, c1 As Object, c2 As Object, datum As Object']
for i,s in enumerate(q1['stages']):
    nm=f'S{i+1:02}_{s["name"]}'
    if 'points' in s:
        body += [f'    OnPlane 1, "{nm}"',f'    segments = Polygon({vb(pts2(s["points"]))})']
        if i==0:body += ['    Set datum = DatumPoint()', '    TwoRelations segments(0).GetStartPoint2, datum, "sgCOINCIDENT"', '    LengthDimension segments(0), 78#, "BaseLength78"','    LengthDimension segments(1), 8#, "BaseThickness8"']
        if i==3:body += ['    LengthDimension segments(0), 16#, "StepWidth16"','    LengthDimension segments(1), 18#, "StepRise18"']
        if i==4:body += ['    LengthDimension segments(0), 5#, "SlotWidth5"','    LengthDimension segments(1), 36#, "SlotDepth36"']
        body += ['    FinishSketch True']
        if s['type']=='boss':body += [f'    Set f = Boss({s["depth"]}#, Array(0#, 0#, 1#), False, "F{i+1:02}_{s["name"]}")']
        else:body += [f'    Set f = Cut(1, 100#, Array(0#, 0#, 1#), False, "F{i+1:02}_{s["name"]}")']
    else:
        body += [f'    OnFace {vb(s["centersWorld"][0])}, "{nm}"',f'    Set c1 = AddCircle({vb(s["centersWorld"][0])}, 3#)',f'    Set c2 = AddCircle({vb(s["centersWorld"][1])}, 3#)','    TwoRelations c1, c2, "sgSAMELENGTH"','    DiameterDimension c1, 6#, "PegDiameter6"','    FinishSketch True',f'    Set f = Boss(6#, {vb(s["direction"])}, False, "F06_Pegs")']
body += ['End Sub']
write(1,70039,'\n'.join(body))

q2=json.loads((ROOT/'q2/native_spec.json').read_text())
t=q2['tangent_points_local_mm']
p=lambda a:[a[0],0,a[1]]
body=['Private Sub BuildPart()','    Dim seg(3) As Object, f As Object, c1 As Object, centerLine As Object, datum As Object, edge As Object, eq As Object','    OnPlane 2, "S01_TangentPlate"',f'    Set seg(0) = AddLine({vb(p(t[0]))}, {vb(p(t[1]))})',f'    Set seg(1) = AddArc({vb(p(t[1]))}, Array(47#, 0#, 0#), {vb(p(t[2]))})',f'    Set seg(2) = AddLine({vb(p(t[2]))}, {vb(p(t[3]))})',f'    Set seg(3) = AddArc({vb(p(t[3]))}, Array(-16#, 0#, 0#), {vb(p(t[0]))})','    JoinLoop seg','    TwoRelations seg(0), seg(1), "sgTANGENT"','    TwoRelations seg(1), seg(2), "sgTANGENT"','    TwoRelations seg(2), seg(3), "sgTANGENT"','    TwoRelations seg(3), seg(0), "sgTANGENT"','    Set centerLine = AddLine(Array(0#, 0#, 0#), Array(38#, 0#, 0#))', '    centerLine.ConstructionGeometry = True', '    Set datum = DatumPoint()', '    TwoRelations centerLine.GetStartPoint2, datum, "sgCOINCIDENT"', '    TwoRelations seg(3).GetCenterPoint2, centerLine.GetStartPoint2, "sgCOINCIDENT"', '    TwoRelations seg(1).GetCenterPoint2, centerLine.GetEndPoint2, "sgCOINCIDENT"', '    LengthDimension centerLine, 38#, "CenterDistance38"', '    RadiusDimension seg(1), 9#, "SmallRadius9"','    RadiusDimension seg(3), 16#, "LargeRadius16"','    FinishSketch True','    Set f = Boss(6#, Array(0#, 1#, 0#), False, "F01_Plate6")','    OnFace Array(0#, 6#, 0#), "S02_LargeBoss"','    Set c1 = AddCircle(Array(0#, 6#, 0#), 16#)','    Set edge = CircleEdgeAt(Array(0#, 6#, 0#), 16#)', '    TwoRelations c1, edge, "sgCONCENTRIC"', '    DiameterDimension c1, 32#, "LargeOuterDiameter32"','    FinishSketch True','    Set f = Boss(8#, Array(0#, 1#, 0#), False, "F02_LargeBossTotal14")','    OnPlane 2, "S03_SmallBoss"','    Set c1 = AddCircle(Array(38#, 0#, 0#), 9#)','    Set edge = CircleEdgeAt(Array(38#, 0#, 0#), 9#)', '    TwoRelations c1, edge, "sgCONCENTRIC"', '    DiameterDimension c1, 18#, "SmallOuterDiameter18"','    FinishSketch True','    Set f = Boss(24#, Array(0#, -1#, 0#), False, "F03_SmallBoss24")','    OnFace Array(0#, 14#, 0#), "S04_LargeHole"','    Set c1 = AddCircle(Array(0#, 14#, 0#), 10#)','    Set edge = CircleEdgeAt(Array(0#, 14#, 0#), 16#)', '    TwoRelations c1, edge, "sgCONCENTRIC"', '    DiameterDimension c1, 20#, "LargeHole20"','    FinishSketch True','    Set f = Cut(1, 100#, Array(0#, -1#, 0#), False, "F04_LargeThroughHole")','    OnFace Array(38#, 6#, 0#), "S05_SmallHole"','    Set c1 = AddCircle(Array(38#, 6#, 0#), 3#)','    Set edge = CircleEdgeAt(Array(38#, 6#, 0#), 9#)', '    TwoRelations c1, edge, "sgCONCENTRIC"', '    DiameterDimension c1, 6#, "SmallHole6"','    FinishSketch True','    Set f = Cut(1, 100#, Array(0#, -1#, 0#), False, "F05_SmallThroughHole")', '    Set eq = model.GetEquationMgr', '    AddEquation eq, """LargeHole"" = 20mm"', '    AddEquation eq, """RadialWall"" = 6mm"', '    AddEquation eq, """LargeRadius16@S01_TangentPlate"" = ""LargeHole"" / 2 + ""RadialWall"""', '    AddEquation eq, """LargeOuterDiameter32@S02_LargeBoss"" = ""LargeHole"" + 2 * ""RadialWall"""', '    AddEquation eq, """LargeHole20@S04_LargeHole"" = ""LargeHole"""', 'End Sub']
write(2,16268,'\n'.join(body))

q3=json.loads((ROOT/'q3/native_spec.json').read_text())
body=['Private Sub BuildPart()','    Dim segments, arc As Object, line1 As Object, line2 As Object, line3 As Object','    Dim f As Object, c(3) As Object, i As Long, datum As Object']
for i,s in enumerate(q3['stageSpecs'][:3]):
    body += [f'    OnPlane 1, "S{i+1:02}_'+['HorizontalPlate','InclinedPlate','EndLip'][i]+'"',f'    segments = Polygon({vb(pts2(s["polyline"]))})']
    if i==0:body += ['    Set datum = DatumPoint()', '    TwoRelations segments(0).GetStartPoint2, datum, "sgCOINCIDENT"', '    LengthDimension segments(0), 76#, "PlateLength76"','    LengthDimension segments(1), 12#, "PlateThickness12"']
    if i==2:body += ['    LengthDimension segments(0), 32#, "LipLength32"']
    body += ['    FinishSketch True',f'    Set f = Boss(60#, Array(0#, 0#, 1#), True, "F{i+1:02}_'+['HorizontalPlate','InclinedPlate','EndLip'][i]+'")']
u=(math.cos(math.pi/6),-math.sin(math.pi/6),0); n=(.5,math.cos(math.pi/6),0)
def slopepoint(s,z,h=15):return [76+u[0]*s+n[0]*h,u[1]*s+n[1]*h,z]
s=q3['stageSpecs'][3]; a=s['wire'][0]; w=s['wire'][1]['points']
body += [f'    OnFace {vb(slopepoint(65,0))}, "S04_R65End"',f'    Set arc = AddArc({vb(slopepoint(*a["start"]))}, {vb(slopepoint(*a["via"]))}, {vb(slopepoint(*a["end"]))})']
body += [f'    Set line{i} = AddLine({vb(slopepoint(*w[i-1]))}, {vb(slopepoint(*w[i]))})' for i in range(1,4)]
body += ['    JoinLoop Array(arc, line1, line2, line3)','    RadiusDimension arc, 65#, "EndRadius65"','    FinishSketch True',f'    Set f = Cut(0, 80#, {vb([-x for x in n])}, False, "F04_R65EndCut")']
s=q3['stageSpecs'][4]
body += ['    OnPlane 1, "S05_CenterSlot"',f'    segments = Polygon({vb(pts2(s["polyline"]))})','    LengthDimension segments(1), 6#, "SlotHeight6"','    FinishSketch True','    Set f = Cut(6, 25#, Array(0#, 0#, 1#), True, "F05_CenterSlot25")','    OnPlane 2, "S06_FourHoles"']
for i,(x,z,r) in enumerate(q3['stageSpecs'][5]['circles']):body += [f'    Set c({i}) = AddCircle(Array({vb(x)}, 0#, {vb(z)}), {vb(r)})']
body += ['    For i = 1 To 3','        TwoRelations c(0), c(i), "sgSAMELENGTH"','    Next','    DiameterDimension c(0), 12#, "HoleDiameter12"','    FinishSketch True','    Set f = Cut(1, 100#, Array(0#, -1#, 0#), False, "F06_FourThroughHoles")','End Sub']
write(3,124768,'\n'.join(body))

q4=json.loads((ROOT/'q4/native_spec.json').read_text())
body=['Private Sub BuildPart()','    Dim seg(5) As Object, f As Object, c1 As Object, c2 As Object, segments','    Dim a As Object, b As Object, c As Object, d As Object, arc As Object','    Dim eq As Object','    OnPlane 1, "S01_OuterProfile_RELATIONS_REQUIRED"']
pos=q4['outerWire'][0]['lineFrom']
for i,s in enumerate(q4['outerWire']):
    if 'lineTo' in s:
        body += [f'    Set seg({i}) = AddLine({vb([*pos,0])}, {vb([*s["lineTo"],0])})'];pos=s['lineTo']
    else:
        body += [f'    Set seg({i}) = AddArc({vb([*pos,0])}, {vb([*s["arcMid"],0])}, {vb([*s["arcEnd"],0])})'];pos=s['arcEnd']
body += ['    JoinLoop seg','    TwoRelations seg(0), seg(5), "sgTANGENT"','    TwoRelations seg(2), seg(3), "sgTANGENT"','    TwoRelations seg(3), seg(4), "sgTANGENT"','    TwoRelations seg(4), seg(5), "sgTANGENT"','    RadiusDimension seg(2), 105#, "TransitionRadius105"','    RadiusDimension seg(3), 20#, "UpperRadius20"','    RadiusDimension seg(5), 21#, "LowerRadius21"','    LengthDimension seg(1), 36#, "EndHeight36"','    FinishSketch False','    Set f = Boss(48#, Array(0#, 0#, 1#), True, "F01_SymmetricWidth48")','    Set eq = model.GetEquationMgr','    AddEquation eq, """FullWidth"" = 48mm"','    AddEquation eq, """NeckWidth"" = 26mm"', '    AddEquation eq, """EndHeight"" = 36mm"', '    AddEquation eq, """BottomOffset"" = 16mm"', '    AddEquation eq, """UpperWall"" = 14mm"', '    AddEquation eq, """EndHeight36@S01_OuterProfile_RELATIONS_REQUIRED"" = ""EndHeight"""','    AddEquation eq, """D1@F01_SymmetricWidth48"" = ""FullWidth"""']
ux,uy=q4['upperCenter'];pr=q4['shoulder']['joinX'];py=q4['shoulder']['horizontalY']
for k,z in enumerate([24,-24]):
    # Closed profile extends safely outside the part; no fixed production geometry.
    # These support edges remain intentionally underdefined rather than adding unshown dimensions.
    # The guide directs the user to replace support edges with converted/linked references.
    sign=1 if z>0 else -1; nm=f'F0{k+2}_Shoulder'+('Front' if z>0 else 'Rear')
    P=lambda x,y:[x,y,z]
    body += [f'    OnFace {vb(P(ux,uy+15))}, "S0{k+2}_Shoulder_R25_LINK_REFERENCES"',f'    Set a = AddLine({vb(P(pr,py))}, {vb(P(100,py))})',f'    Set b = AddLine({vb(P(100,py))}, {vb(P(100,100))})',f'    Set c = AddLine({vb(P(100,100))}, {vb(P(ux-25,100))})',f'    Set d = AddLine({vb(P(ux-25,100))}, {vb(P(ux-25,uy))})',f'    Set arc = AddArc({vb(P(ux-25,uy))}, {vb(P(ux,uy-25))}, {vb(P(pr,py))})','    JoinLoop Array(a, b, c, d, arc)','    RadiusDimension arc, 25#, "ShoulderRadius25"','    FinishSketch False',f'    Set f = Cut(0, 11#, Array(0#, 0#, {-sign}#), False, "{nm}")',f'    AddEquation eq, """D1@{nm}"" = (""FullWidth"" - ""NeckWidth"") / 2"']
body += ['    OnPlane 1, "S04_TwoHoles_CONCENTRIC_REFERENCES_REQUIRED"','    Set c1 = AddCircle(Array(0#, 0#, 0#), 8#)',f'    Set c2 = AddCircle({vb([ux,uy,0])}, 8#)','    TwoRelations c1, c2, "sgSAMELENGTH"','    DiameterDimension c1, 16#, "HoleDiameter16"','    FinishSketch False','    Set f = CutBoth("F04_TwoThroughHoles")','    OnPlane 1, "S05_SideSlot_RELATIONS_REQUIRED"','    Set a = AddLine(Array(44#, -6#, 0#), Array(77#, -6#, 0#))','    Set b = AddLine(Array(77#, -6#, 0#), Array(77#, 6#, 0#))','    Set c = AddLine(Array(77#, 6#, 0#), Array(44#, 6#, 0#))','    Set arc = AddArc(Array(44#, 6#, 0#), Array(38#, 0#, 0#), Array(44#, -6#, 0#))','    JoinLoop Array(a, b, c, arc)','    TwoRelations a, arc, "sgTANGENT"','    TwoRelations c, arc, "sgTANGENT"','    LengthDimension a, 33#, "SlotDepth33"','    LengthDimension b, 12#, "SideSlotWidthDerived12"','    FinishSketch False','    Set f = CutBoth("F05_SideSlotDerived12")', '    AddEquation eq, """SideSlotWidthDerived12@S05_SideSlot_RELATIONS_REQUIRED"" = 2 * (""EndHeight"" - ""BottomOffset"" - ""UpperWall"")"','    OnPlane 2, "S06_CenterFork_SYMMETRY_RELATIONS_REQUIRED"','    segments = Polygon(Array(Array(33#, 0#, -14#), Array(77#, 0#, -14#), Array(77#, 0#, 14#), Array(33#, 0#, 14#)))','    LengthDimension segments(0), 44#, "ForkDepth44"','    LengthDimension segments(1), 28#, "ForkWidth28"','    FinishSketch False','    Set f = CutBoth("F06_CenterFork28")','    Log "Q4: AUTO DIMENSIONING DELIBERATELY DISABLED. Add original design relations manually before save."','    Log "Both shoulder depths are linked to (FullWidth-NeckWidth)/2; main width uses Mid Plane."','End Sub']
write(4,201961,'\n'.join(body))
print('Created',*[p.name for p in OUT.glob('*.bas')])
