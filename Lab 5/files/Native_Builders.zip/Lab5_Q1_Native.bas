Attribute VB_Name = "Lab5_Q1_Native"
Option Explicit
' Lab 5 native SOLIDWORKS helper SOURCE. Not executed in SOLIDWORKS here.
' API dimensions: metres. Input point lists: millimetres in model coordinates.
' This source creates native sketches and boss/cut features, never imported bodies.
' Production geometry is never fixed. Q4 does not add automatic coordinate dimensions.
Private app As Object, model As Object, sm As Object, fm As Object, mu As Object
Private sketch As Object, sketchFeat As Object, fs As Object, logFile As Object
Private outputFolder As String, stage As String, oldPrompt As Boolean, oldPromptSaved As Boolean
Private qNumber As Long, refVolume As Double, unresolved As Long

Public Sub main()
    On Error GoTo Failed
    qNumber = 1
    refVolume = 70039#
    Initialise
    BuildPart
    model.ForceRebuild3 False
    model.ShowNamedView2 "", 7
    model.ViewZoomtofit2
    Log "BUILT native feature draft. Volume mm3=" & CStr(VolumeMM3())
    Log "Unresolved sketches reported during build=" & CStr(unresolved)
    RestorePreferences
    CloseLog
    MsgBox "Native feature draft created in a NEW UNSAVED part." & vbCrLf & _
           "This source was not executed in the authoring environment." & vbCrLf & _
           "Inspect every Edit Sketch / Edit Feature, then run SaveCheckedPart." & vbCrLf & _
           "Unresolved sketch count during build: " & CStr(unresolved) & vbCrLf & _
           "Run log: " & outputFolder, vbInformation, "Lab 5 Q" & CStr(qNumber)
    Exit Sub
Failed:
    Log "STOP at " & stage & ": " & Err.Number & " " & Err.Description
    RestorePreferences
    CloseLog
    MsgBox "Build stopped at " & stage & vbCrLf & Err.Description & vbCrLf & _
           "No SLDPRT was saved. Inspect the new unsaved part and log.", vbCritical
End Sub

Private Sub Initialise()
    Dim template As String, parent As String
    stage = "Create NEW part"
    Set app = Application.SldWorks
    If app Is Nothing Then Fail "Run this module inside SOLIDWORKS VBA."
    Set fs = CreateObject("Scripting.FileSystemObject")
    parent = CreateObject("WScript.Shell").SpecialFolders("MyDocuments")
    outputFolder = parent & "\Lab5_Q" & CStr(qNumber) & "_" & Format$(Now, "yyyymmdd_hhnnss")
    If fs.FolderExists(outputFolder) Then outputFolder = outputFolder & "_" & CStr(Int(Timer * 100))
    fs.CreateFolder outputFolder
    Set logFile = fs.CreateTextFile(outputFolder & "\NativeBuildLog.txt", True, True)
    Log "UNEXECUTED source supplied for local SOLIDWORKS 2026 testing."
    template = app.GetUserPreferenceStringValue(8)
    If Len(template) = 0 Then template = InputBox("Full path to a normal Part template (.prtdot):", "Lab 5")
    If Len(template) = 0 Then Fail "No part template selected."
    Set model = app.NewDocument(template, 0, 0, 0)
    If model Is Nothing Then Fail "Cannot create part from selected template."
    Set sm = model.SketchManager
    Set fm = model.FeatureManager
    Set mu = app.GetMathUtility
    model.SetUnits 0, 1, 0, 3, False
    oldPrompt = app.GetUserPreferenceToggle(10)
    oldPromptSaved = True
    app.SetUserPreferenceToggle 10, False
End Sub

Private Sub OnPlane(ByVal number As Long, ByVal nm As String)
    Dim f As Object, n As Long
    model.ClearSelection2 True
    Set f = model.FirstFeature
    Do While Not f Is Nothing
        If f.GetTypeName2 = "RefPlane" Then
            n = n + 1
            If n = number Then
                If Not f.Select2(False, 0) Then Fail "Reference plane selection failed."
                StartSketch nm
                Exit Sub
            End If
        End If
        Set f = f.GetNextFeature
    Loop
    Fail "Default reference plane not found. Use a normal Part template."
End Sub

Private Sub OnFace(point, ByVal nm As String)
    Dim b As Object, faces, i As Long, f As Object, p, near
    Set b = Body()
    faces = b.GetFaces
    p = Array(CDbl(point(0)) / 1000#, CDbl(point(1)) / 1000#, CDbl(point(2)) / 1000#)
    For i = 0 To UBound(faces)
        Set f = faces(i)
        If f.GetSurface.IsPlane Then
            near = f.GetClosestPointOn(p(0), p(1), p(2))
            If Not IsEmpty(near) Then
                If (near(0) - p(0)) ^ 2 + (near(1) - p(1)) ^ 2 + (near(2) - p(2)) ^ 2 < 0.00000000000001 Then
                    model.ClearSelection2 True
                    If Not f.Select4(False, Nothing) Then Fail "Sketch face selection failed."
                    StartSketch nm
                    Exit Sub
                End If
            End If
        End If
    Next
    Fail "Planar support face not found for " & nm
End Sub

Private Sub StartSketch(ByVal nm As String)
    stage = nm
    sm.InsertSketch True
    Set sketch = sm.ActiveSketch
    If sketch Is Nothing Then Fail "Sketch could not be started."
    Set sketchFeat = sketch.GetFeature
    sketchFeat.Name = nm
    model.ClearSelection2 True
End Sub

Private Function LocalPoint(point)
    Dim p As Object, v
    Set p = mu.CreatePoint(Array(CDbl(point(0)) / 1000#, CDbl(point(1)) / 1000#, CDbl(point(2)) / 1000#))
    Set p = p.MultiplyTransform(sketch.ModelToSketchTransform)
    v = p.ArrayData
    If Abs(v(2)) > 0.000001 Then Fail "Input point does not lie in the sketch plane."
    LocalPoint = v
End Function

Private Function AddLine(p0, p1) As Object
    Dim a, b
    a = LocalPoint(p0): b = LocalPoint(p1)
    sm.AddToDB = True
    Set AddLine = sm.CreateLine(a(0), a(1), 0#, b(0), b(1), 0#)
    sm.AddToDB = False
    If AddLine Is Nothing Then Fail "Line creation failed."
    If Abs(a(0) - b(0)) < 0.0000001 Then OneRelation AddLine, "sgVERTICAL2D"
    If Abs(a(1) - b(1)) < 0.0000001 Then OneRelation AddLine, "sgHORIZONTAL2D"
End Function

Private Function AddArc(p0, pm, p1) As Object
    Dim a, b, c
    a = LocalPoint(p0): b = LocalPoint(pm): c = LocalPoint(p1)
    sm.AddToDB = True
    Set AddArc = sm.Create3PointArc(a(0), a(1), 0#, c(0), c(1), 0#, b(0), b(1), 0#)
    sm.AddToDB = False
    If AddArc Is Nothing Then Fail "Three-point arc creation failed."
End Function

Private Function AddCircle(center, ByVal radius As Double) As Object
    Dim p
    p = LocalPoint(center)
    sm.AddToDB = True
    Set AddCircle = sm.CreateCircleByRadius(p(0), p(1), 0#, radius / 1000#)
    sm.AddToDB = False
    If AddCircle Is Nothing Then Fail "Circle creation failed."
End Function

Private Function Polygon(points)
    Dim result(), i As Long
    ReDim result(UBound(points))
    For i = 0 To UBound(points)
        Set result(i) = AddLine(points(i), points((i + 1) Mod (UBound(points) + 1)))
    Next
    JoinLoop result
    Polygon = result
End Function

Private Sub JoinLoop(segments)
    Dim i As Long
    For i = 0 To UBound(segments)
        TwoRelations segments(i).GetEndPoint2, segments((i + 1) Mod (UBound(segments) + 1)).GetStartPoint2, "sgCOINCIDENT"
    Next
End Sub

Private Sub OneRelation(ByVal a As Object, ByVal relation As String)
    model.ClearSelection2 True
    If Not a.Select4(False, Nothing) Then Fail "Cannot select relation entity."
    model.SketchAddConstraints relation
End Sub

Private Sub TwoRelations(ByVal a As Object, ByVal b As Object, ByVal relation As String)
    model.ClearSelection2 True
    If Not a.Select4(False, Nothing) Then Fail "Cannot select first relation entity."
    If Not b.Select4(True, Nothing) Then Fail "Cannot select second relation entity."
    model.SketchAddConstraints relation
End Sub

Private Function AnnotationAt(ByVal x As Double, ByVal y As Double)
    Dim p As Object
    Set p = mu.CreatePoint(Array(x, y, 0#))
    Set p = p.MultiplyTransform(sketch.ModelToSketchTransform.Inverse)
    AnnotationAt = p.ArrayData
End Function

Private Sub LengthDimension(ByVal seg As Object, ByVal mm As Double, ByVal nm As String)
    Dim p As Object, q As Object, a, dd As Object
    Set p = seg.GetStartPoint2: Set q = seg.GetEndPoint2
    a = AnnotationAt((p.X + q.X) / 2# + 0.008, (p.Y + q.Y) / 2# + 0.008)
    model.ClearSelection2 True
    seg.Select4 False, Nothing
    Set dd = model.AddDimension2(a(0), a(1), a(2))
    SetDimension dd, mm / 1000#, nm
End Sub

Private Sub RadiusDimension(ByVal seg As Object, ByVal mm As Double, ByVal nm As String)
    Dim p As Object, a, dd As Object
    Set p = seg.GetCenterPoint2
    a = AnnotationAt(p.X + mm / 1400#, p.Y + mm / 1400#)
    model.ClearSelection2 True
    seg.Select4 False, Nothing
    Set dd = model.AddRadialDimension2(a(0), a(1), a(2))
    SetDimension dd, mm / 1000#, nm
End Sub

Private Sub DiameterDimension(ByVal seg As Object, ByVal mm As Double, ByVal nm As String)
    Dim p As Object, a, dd As Object
    Set p = seg.GetCenterPoint2
    a = AnnotationAt(p.X + mm / 1400#, p.Y + mm / 1400#)
    model.ClearSelection2 True
    seg.Select4 False, Nothing
    Set dd = model.AddDiameterDimension2(a(0), a(1), a(2))
    SetDimension dd, mm / 1000#, nm
End Sub

Private Sub SetDimension(ByVal dd As Object, ByVal value As Double, ByVal nm As String)
    Dim dimension As Object
    If dd Is Nothing Then Fail "Dimension creation failed: " & nm
    Set dimension = dd.GetDimension2(0)
    dimension.Name = nm
    dimension.SystemValue = value
    model.ClearSelection2 True
End Sub

Private Function DatumPoint() As Object
    sm.AddToDB = True
    Set DatumPoint = sm.CreatePoint(0#, 0#, 0#)
    sm.AddToDB = False
    OneRelation DatumPoint, "sgFIXED"
End Function

Private Sub AddEquation(ByVal eq As Object, ByVal expression As String)
    Dim result As Long
    result = eq.Add2(-1, expression, True)
    If result < 0 Then Fail "Equation creation failed: " & expression
End Sub

Private Function CircleEdgeAt(center, ByVal radius As Double) As Object
    Dim b As Object, edges, i As Long, e As Object, p, curve As Object
    Set b = Body()
    edges = b.GetEdges
    For i = 0 To UBound(edges)
        Set e = edges(i)
        Set curve = e.GetCurve
        If curve.IsCircle Then
            p = curve.CircleParams
            If Abs(p(0) * 1000# - CDbl(center(0))) < 0.001 And _
               Abs(p(1) * 1000# - CDbl(center(1))) < 0.001 And _
               Abs(p(2) * 1000# - CDbl(center(2))) < 0.001 And _
               Abs(p(6) * 1000# - radius) < 0.001 Then
                Set CircleEdgeAt = e
                Exit Function
            End If
        End If
    Next
    Fail "Circular reference edge not found."
End Function

Private Sub FinishSketch(ByVal autoDimension As Boolean)
    Dim datum As Object, result As Long
    If autoDimension And Not sketch.IsFullyDefined Then
        ' Only a standalone reference datum is fixed; no production lines, arcs or circles.
        sm.AddToDB = True
        Set datum = sm.CreatePoint(0#, 0#, 0#)
        sm.AddToDB = False
        OneRelation datum, "sgFIXED"
        model.ClearSelection2 True
        result = sm.FullyDefineSketch(True, False, 0, True, 1, datum, 1, datum, 0, 0)
        Log "FullyDefineSketch status=" & CStr(result) & "; " & sketchFeat.Name
    End If
    If Not sketch.IsFullyDefined Then
        unresolved = unresolved + 1
        Log "UNDERDEFINED: " & sketchFeat.Name & "; complete dimensions/relations before saving."
    Else
        Log "Fully defined: " & sketchFeat.Name
    End If
    model.ClearSelection2 True
    sm.InsertSketch True
    model.ClearSelection2 True
    If Not sketchFeat.Select2(False, 0) Then Fail "Completed sketch selection failed."
End Sub

Private Function IsReverse(direction, ByVal cut As Boolean) As Boolean
    Dim n As Object, a, dot As Double
    Set n = mu.CreateVector(Array(0#, 0#, 1#))
    Set n = n.MultiplyTransform(sketch.ModelToSketchTransform.Inverse)
    a = n.ArrayData
    dot = a(0) * CDbl(direction(0)) + a(1) * CDbl(direction(1)) + a(2) * CDbl(direction(2))
    If Abs(dot) < 0.99 Then Fail "Requested direction is not normal to the sketch."
    If cut Then dot = -dot
    IsReverse = (dot < 0#)
End Function

Private Function Boss(ByVal mm As Double, direction, ByVal midPlane As Boolean, ByVal nm As String) As Object
    Dim f As Object, mode As Long
    If midPlane Then mode = 6 Else mode = 0
    stage = nm
    Set f = fm.FeatureExtrusion2(True, False, IsReverse(direction, False), mode, 0, mm / 1000#, 0#, False, False, False, False, 0#, 0#, False, False, False, False, True, True, True, 0, 0#, False)
    If f Is Nothing Then Fail "Boss feature creation failed."
    f.Name = nm
    VerifyBody
    Set Boss = f
End Function

Private Function Cut(ByVal mode As Long, ByVal mm As Double, direction, ByVal midPlane As Boolean, ByVal nm As String) As Object
    Dim f As Object
    stage = nm
    If midPlane Then mode = 6
    Set f = fm.FeatureCut3(True, False, IsReverse(direction, True), mode, 0, mm / 1000#, 0#, False, False, False, False, 0#, 0#, False, False, False, False, False, True, True, False, False, False, 0, 0#, False)
    If f Is Nothing Then Fail "Cut feature creation failed."
    f.Name = nm
    VerifyBody
    Set Cut = f
End Function

Private Function CutBoth(ByVal nm As String) As Object
    Dim f As Object
    stage = nm
    Set f = fm.FeatureCut3(False, False, False, 1, 1, 0.2, 0.2, False, False, False, False, 0#, 0#, False, False, False, False, False, True, True, False, False, False, 0, 0#, False)
    If f Is Nothing Then Fail "Bidirectional through-all cut failed."
    f.Name = nm
    VerifyBody
    Set CutBoth = f
End Function

Private Function Body() As Object
    Dim bodies
    bodies = model.GetBodies2(0, False)
    If IsEmpty(bodies) Then Fail "No solid body exists."
    If UBound(bodies) <> 0 Then Fail "Expected exactly ONE solid body."
    Set Body = bodies(0)
End Function

Private Function VolumeMM3() As Double
    Dim mp As Object
    model.ClearSelection2 True
    Set mp = model.Extension.CreateMassProperty
    mp.UseSystemUnits = True
    VolumeMM3 = mp.Volume * 1000000000#
End Function

Private Sub VerifyBody()
    Dim b As Object
    model.ForceRebuild3 False
    Set b = Body()
    If VolumeMM3() <= 0# Then Fail "Nonpositive solid volume."
    Log stage & ": ONE solid, volume mm3=" & CStr(VolumeMM3())
End Sub

Public Sub SaveCheckedPart()
    Dim f As Object, s As Object, vol As Double, path As String, e As Long, w As Long, ok As Boolean
    On Error GoTo Failed
    Set app = Application.SldWorks
    Set model = app.ActiveDoc
    If model Is Nothing Then Fail "Open the generated native part first."
    If model.GetType <> 1 Then Fail "Active document must be a part."
    Set fs = CreateObject("Scripting.FileSystemObject")
    Set f = model.FirstFeature
    Do While Not f Is Nothing
        CheckFeatureSketches f
        Set f = f.GetNextFeature
    Loop
    model.ForceRebuild3 False
    VerifyBody
    vol = VolumeMM3()
    If Abs(vol - 70039#) > 70039# * 0.01 Then Fail "Reference volume tolerance not met. Volume mm3=" & CStr(vol)
    path = InputBox("Full NEW .SLDPRT path; required basename Q" & CStr(1) & ".sldprt:", "Save checked native part", _
           CreateObject("WScript.Shell").SpecialFolders("MyDocuments") & "\Q" & CStr(1) & ".sldprt")
    If Len(path) = 0 Then Exit Sub
    If LCase$(fs.GetFileName(path)) <> "q" & CStr(1) & ".sldprt" Then Fail "Use the exact required file name."
    If fs.FileExists(path) Then Fail "File already exists. Choose a new directory."
    ok = model.Extension.SaveAs(path, 0, 1, Nothing, e, w)
    If Not ok Or e <> 0 Then Fail "SaveAs failed; error code " & CStr(e)
    MsgBox "Saved native feature part: " & path & vbCrLf & "Volume mm3=" & CStr(vol) & "; warnings=" & CStr(w), vbInformation
    Exit Sub
Failed:
    MsgBox "Native save did not complete: " & Err.Description, vbExclamation
End Sub

Private Sub CheckFeatureSketches(ByVal f As Object)
    Dim s As Object, child As Object
    If f.GetTypeName2 = "ProfileFeature" Then
        Set s = f.GetSpecificFeature2
        If Not s.IsFullyDefined Then Fail "Sketch is still underdefined: " & f.Name
    End If
    Set child = f.GetFirstSubFeature
    Do While Not child Is Nothing
        CheckFeatureSketches child
        Set child = child.GetNextSubFeature
    Loop
End Sub

Private Sub Fail(ByVal message As String)
    Err.Raise vbObjectError + 2105, "Lab5", message
End Sub

Private Sub Log(ByVal message As String)
    Debug.Print message
    If Not logFile Is Nothing Then logFile.WriteLine message
End Sub

Private Sub CloseLog()
    On Error Resume Next
    If Not logFile Is Nothing Then logFile.Close
    Set logFile = Nothing
    On Error GoTo 0
End Sub

Private Sub RestorePreferences()
    On Error Resume Next
    If Not sm Is Nothing Then sm.AddToDB = False
    If oldPromptSaved Then app.SetUserPreferenceToggle 10, oldPrompt
    On Error GoTo 0
End Sub

Private Sub BuildPart()
    Dim segments, f As Object, c1 As Object, c2 As Object, datum As Object
    OnPlane 1, "S01_Base"
    segments = Polygon(Array(Array(0.0#, 0.0#, 0.0#), Array(78.0#, 0.0#, 0.0#), Array(78.0#, 8.0#, 0.0#), Array(0.0#, 8.0#, 0.0#)))
    Set datum = DatumPoint()
    TwoRelations segments(0).GetStartPoint2, datum, "sgCOINCIDENT"
    LengthDimension segments(0), 78#, "BaseLength78"
    LengthDimension segments(1), 8#, "BaseThickness8"
    FinishSketch True
    Set f = Boss(28#, Array(0#, 0#, 1#), False, "F01_Base")
    OnPlane 1, "S02_Ramp"
    segments = Polygon(Array(Array(27.87600088797#, 8.0#, 0.0#), Array(78.0#, 8.0#, 0.0#), Array(78.0#, 45.498936959406#, 0.0#), Array(51.19138379572#, 58.0#, 0.0#)))
    FinishSketch True
    Set f = Boss(28#, Array(0#, 0#, 1#), False, "F02_Ramp")
    OnPlane 1, "S03_LowerStep"
    segments = Polygon(Array(Array(0.0#, 8.0#, 0.0#), Array(40.0#, 8.0#, 0.0#), Array(40.0#, 16.0#, 0.0#), Array(0.0#, 16.0#, 0.0#)))
    FinishSketch True
    Set f = Boss(18#, Array(0#, 0#, 1#), False, "F03_LowerStep")
    OnPlane 1, "S04_UpperStep"
    segments = Polygon(Array(Array(24.0#, 16.0#, 0.0#), Array(40.0#, 16.0#, 0.0#), Array(40.0#, 34.0#, 0.0#), Array(24.0#, 34.0#, 0.0#)))
    LengthDimension segments(0), 16#, "StepWidth16"
    LengthDimension segments(1), 18#, "StepRise18"
    FinishSketch True
    Set f = Boss(18#, Array(0#, 0#, 1#), False, "F04_UpperStep")
    OnPlane 1, "S05_Slot"
    segments = Polygon(Array(Array(64.7860006012697#, 51.6607260738895#, 0.0#), Array(69.317539536453#, 49.547634765186#, 0.0#), Array(54.1032821137878#, 16.9205544318666#, 0.0#), Array(49.5717431786045#, 19.0336457405701#, 0.0#)))
    LengthDimension segments(0), 5#, "SlotWidth5"
    LengthDimension segments(1), 36#, "SlotDepth36"
    FinishSketch True
    Set f = Cut(1, 100#, Array(0#, 0#, 1#), False, "F05_Slot")
    OnFace Array(57.9886921984948#, 54.8303630369448#, 7.0#), "S06_Pegs"
    Set c1 = AddCircle(Array(57.9886921984948#, 54.8303630369448#, 7.0#), 3#)
    Set c2 = AddCircle(Array(57.9886921984948#, 54.8303630369448#, 21.0#), 3#)
    TwoRelations c1, c2, "sgSAMELENGTH"
    DiameterDimension c1, 6#, "PegDiameter6"
    FinishSketch True
    Set f = Boss(6#, Array(0.4226182617407#, 0.9063077870366#, 0.0#), False, "F06_Pegs")
End Sub